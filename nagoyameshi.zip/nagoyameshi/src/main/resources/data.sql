--storesテーブル
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (1 , 1 , '串焼き 鳥人', 'store01.jpg', '串焼きにこだわった老舗のお店です。', '10', '3000', '4000', '18:00', '1:00', '水、日', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (2, 1 , '海鮮居酒屋 海', 'store02.jpg', '活きの良い海鮮を提供するお店です。', '10', '4000', '5000', '19:00', '3:00', '月', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (3, 1 , '蔵', 'store03.jpg', 'アットホームな空間で楽しくお食事できます。', '10', '4000', '5000', '17:00', '3:00', '年中無休', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (4, 2, '和乃助', 'store04.jpg', '落ち着いた空間で自慢の一品をお楽しみください。', '10', '6000', '7000', '19:00', '24:00', '日', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (5, 2, 'さか山', 'store05.jpg', '創作日本食をメインに提供するお店です。', '10', '5000', '6000', '19:00', '3:00', '月', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (6, 3, '廣寿司', 'store06.jpg', '長年修行を積んだ大将が握る絶品のお寿司です。', '10', '7000', '8000', '19:00', '22:00', '月', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (7, 4, 'ガラムサラム', 'store07.jpg', '本場のインド料理を堪能できます。', '10', '2000', '3000', '10:00', '17:00', '日・月', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (8, 5, 'ファミリーレストラン ファンタジア', 'store08.jpg', 'ファミリールーム完備でお子様も楽しめます。', '10', '2000', '3000', '0:00', '24:00', '年中無休', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (9, 6, 'イタリアン・ダイナー', 'store09.jpg', 'シェフの繊細なお料理を楽しめます。', '10', '6000', '7000', '19:00', '23:00', '日・火', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (10, 7, '釜山', 'store10.jpg', '本場韓国の味を再現した料理が揃っています。', '10', '4000', '5000', '17:00', '22:00', '日・月', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (11, 8, '牛園', 'store11.jpg', 'A5ランクの厳選したお肉を取り揃えています。', '10', '5000', '6000', '15:00', '21:00', '水', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (12, 9, '博多ラーメン まるやま', 'store12.jpg', '本場博多の味を楽しめます。', '10', '1000', '2000', '12:00', '24:00', '年中無休', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (13, 10, 'STELLA', 'store13.jpg', '落ち着いた空間でお酒を楽しめます。', '10', '2000', '3000', '21:00', '5:00', '日・水', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');
INSERT IGNORE INTO stores (id, category_id, store_name, image_name, description, capacity, min_budget, max_budget, opening_time, closing_time, regular_holiday, postal_code, address, phone_number)
VALUES (14, 11, '珈琲館', 'store14.jpg', 'レトロな店内が懐かしさを感じさせてくれます。', '10', '1000', '2000', '8:00', '15:00', '月', '123-4567', '愛知県名古屋市××町123−4', '080-1234-5678');

-- rolesテーブル
INSERT IGNORE INTO roles (id, role_name) VALUES (1, 'ROLE_GENERAL');--一般会員
INSERT IGNORE INTO roles (id, role_name) VALUES (2, 'ROLE_PAID');--有料会員
INSERT IGNORE INTO roles (id, role_name) VALUES (3, 'ROLE_ADMIN');--管理者

--usersテーブル
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (1, '侍 太郎', 'サムライ タロウ', '101-0022', '東京都千代田区神田練塀町300番地', '090-1234-5678', 'taro.samurai@example.com', '$2a$10$2JNjTwZBwo7fprL2X4sv.OEKqxnVtsVQvuXDkI8xVGix.U3W5B7CO', 1, true);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (2, '侍 花子', 'サムライ ハナコ', '101-0022', '東京都千代田区神田練塀町300番地', '090-1234-5678', 'hanako.samurai@example.com', '$2a$10$2JNjTwZBwo7fprL2X4sv.OEKqxnVtsVQvuXDkI8xVGix.U3W5B7CO', 3, true);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (3, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (4, '侍 幸美', 'サムライ サチミ', '342-0006', '埼玉県吉川市南広島X-XX-XX', '090-1234-5678', 'sachimi.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (5, '侍 雅', 'サムライ ミヤビ', '527-0209', '滋賀県東近江市佐目町X-XX-XX', '090-1234-5678', 'miyabi.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (6, '侍 正保', 'サムライ マサヤス', '989-1203', '宮城県柴田郡大河原町旭町X-XX-XX', '090-1234-5678', 'masayasu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (7, '侍 真由美', 'サムライ マユミ', '951-8015', '新潟県新潟市松岡町X-XX-XX', '090-1234-5678', 'mayumi.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (8, '侍 安民', 'サムライ ヤスタミ', '241-0033', '神奈川県横浜市旭区今川町X-XX-XX', '090-1234-5678', 'yasutami.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (9, '侍 章緒', 'サムライ アキオ', '739-2103', '広島県東広島市高屋町宮領X-XX-XX', '090-1234-5678', 'akio.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (10, '侍 祐子', 'サムライ ユウコ', '601-0761', '京都府南丹市美山町高野X-XX-XX', '090-1234-5678', 'yuko.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) 
VALUES (11, '侍 秋美', 'サムライ アキミ', '606-8235', '京都府京都市左京区田中西春菜町X-XX-XX', '090-1234-5678', 'akimi.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, user_name, furigana, postal_code, address, phone_number, email, password, role_id, enabled) --role_idをアップデートして無料か有料かを識別できるようにする
VALUES (12, '侍 信平', 'サムライ シンペイ', '673-1324', '兵庫県加東市新定X-XX-XX', '090-1234-5678', 'shinpei.samurai@example.com', 'password', 1, false);

--reservationsテーブル
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (1, 1, 1, '2023-04-01', '20:00', 2);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (2, 2, 1, '2023-04-01', '20:00', 3);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (3, 3, 1, '2023-04-01', '20:00', 4);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (4, 4, 1, '2023-04-01', '20:00', 5);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (5, 5, 1, '2023-04-01', '20:00', 6);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (6, 6, 1, '2023-04-01', '20:00', 2);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (7, 7, 1, '2023-04-01', '13:00', 3);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (8, 8, 1, '2023-04-01', '20:00', 4);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (9, 9, 1, '2023-04-01', '20:00', 5);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (10, 10, 1, '2023-04-01', '20:00', 6);
INSERT IGNORE INTO reservations (id, store_id, user_id, reservation_date, reservation_time, number_of_people) 
VALUES (11, 11, 1, '2023-04-01', '20:00', 2);

--categoriesテーブル
INSERT IGNORE INTO categories (id, category_name) VALUES (1, '居酒屋');
INSERT IGNORE INTO categories (id, category_name) VALUES (2, '和食・日本食');
INSERT IGNORE INTO categories (id, category_name) VALUES (3, '鮨');
INSERT IGNORE INTO categories (id, category_name) VALUES (4, 'アジア料理');
INSERT IGNORE INTO categories (id, category_name) VALUES (5, 'その他レストラン');
INSERT IGNORE INTO categories (id, category_name) VALUES (6, '洋食・西洋料理');
INSERT IGNORE INTO categories (id, category_name) VALUES (7, '韓国料理');
INSERT IGNORE INTO categories (id, category_name) VALUES (8, '焼肉');
INSERT IGNORE INTO categories (id, category_name) VALUES (9, 'ラーメン');
INSERT IGNORE INTO categories (id, category_name) VALUES (10, 'バー');
INSERT IGNORE INTO categories (id, category_name) VALUES (11, 'カフェ・喫茶店');
--INSERT IGNORE INTO categories (id, category_name) VALUES (12, 'ファストフード');
--INSERT IGNORE INTO categories (id, category_name) VALUES (13, '中華料理');
--INSERT IGNORE INTO categories (id, category_name) VALUES (14, 'スイーツ');

-- reviewsテーブル
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (1, 1, 1, 5, 'とても良い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (2, 1, 2, 3, '良い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (3, 1, 3, 2, '悪い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (4, 1, 4, 3, '良い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (5, 1, 5, 4, 'とても良い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (6, 1, 6, 4, '良い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (7, 1, 7, 3, '良い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (8, 1, 8, 5, 'とても良い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (9, 1, 9, 4, '良い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (10, 1, 10, 5, 'とても良い');
INSERT IGNORE INTO reviews (id, store_id, user_id, star_rating, comment) VALUES (11, 1, 11, 5, '良い');

--favoritesテーブル
INSERT IGNORE INTO favorites (id, store_id, user_id) VALUES (1, 1, 1);
INSERT IGNORE INTO favorites (id, store_id, user_id) VALUES (2, 2, 1);
INSERT IGNORE INTO favorites (id, store_id, user_id) VALUES (3, 3, 1);
INSERT IGNORE INTO favorites (id, store_id, user_id) VALUES (4, 4, 1);
INSERT IGNORE INTO favorites (id, store_id, user_id) VALUES (5, 5, 1);
INSERT IGNORE INTO favorites (id, store_id, user_id) VALUES (6, 1, 2);
INSERT IGNORE INTO favorites (id, store_id, user_id) VALUES (7, 1, 3);