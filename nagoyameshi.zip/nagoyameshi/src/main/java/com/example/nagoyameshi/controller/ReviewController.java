package com.example.nagoyameshi.controller;

import java.security.Principal;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.nagoyameshi.entity.Review;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ReviewEditForm;
import com.example.nagoyameshi.form.ReviewPostForm;
import com.example.nagoyameshi.repository.ReviewRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.security.UserDetailsImpl;
import com.example.nagoyameshi.service.ReviewService;

@Controller
@RequestMapping("/stores/{id}")
public class ReviewController {
	private final ReviewRepository reviewRepository;
	private final ReviewService reviewService;
	private final StoreRepository storeRepository;

	public ReviewController(ReviewRepository reviewRepository, ReviewService reviewService,
			StoreRepository storeRepository) {
		this.reviewRepository = reviewRepository;
		this.reviewService = reviewService;
		this.storeRepository = storeRepository;
	}

	//レビュー投稿ページ用
	@GetMapping("/reviewpost")
	public String reviewPost(@PathVariable(name = "id") Integer id, Model model) {
		Store store = storeRepository.getReferenceById(id);

		model.addAttribute("reviewPostForm", new ReviewPostForm());
		model.addAttribute("store", store);

		return "reviews/post";
	}

	//レビュー一覧ページ用
	@GetMapping("/allreview")
	public String allReview(@PathVariable(name = "id") Integer storeId,
			@PageableDefault(page = 0, size = 10, sort = "updatedAt", direction = Direction.DESC) Pageable pageable,
			@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
			Store store, Model model) {

		Store store1 = storeRepository.getReferenceById(storeId);
		Page<Review> reviewPage = reviewRepository.findByStore(store1, pageable);
		//ログインユーザーの情報を取得（ログインしていない場合は null）
		User user = (userDetailsImpl != null) ? userDetailsImpl.getUser() : null;

		model.addAttribute("reviewPage", reviewPage);
		model.addAttribute("store", store1);
		model.addAttribute("user", user);

		return "reviews/allreview";
	}

	//レビュー作成フォーム用（DBとやりとり）
	@PostMapping("/reviewcreate")
	public String reviewCreate(@PathVariable(name = "id") Integer storeId,
			@ModelAttribute @Validated ReviewPostForm reviewPostForm, BindingResult bindingResult,
			@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
			RedirectAttributes redirectAttributes,
			Model model, Principal principal) {

		if (bindingResult.hasErrors()) {
			return "reviews/post";
		}

		//ログインユーザーの情報を取得
		User user = userDetailsImpl.getUser();

		reviewService.reviewCreate(reviewPostForm, storeId, user);
		redirectAttributes.addFlashAttribute("successMessage", "レビューを投稿しました。");
		return "redirect:/stores/" + storeId;
	}

	//レビュー編集フォーム取得
	@GetMapping("/reviewedit/{reviewId}")
	public String reviewEdit(@PathVariable(name = "id") Integer storeId,
			@PathVariable(name = "reviewId") Integer reviewId, Model model) {
		Store store = storeRepository.getReferenceById(storeId);
		Review review = reviewRepository.getReferenceById(reviewId);
		ReviewEditForm reviewEditForm = new ReviewEditForm(review.getId(), review.getStarRating(),
				review.getComment());

		model.addAttribute("store", store);
		model.addAttribute("reviewEditForm", reviewEditForm);

		return "reviews/edit";
	}

	//編集したレビューの登録
	@PostMapping("/reviewupdate")
	public String reviewUpdate(@PathVariable(name = "id") Integer storeId,
			@ModelAttribute @Validated ReviewEditForm reviewEditForm, BindingResult bindingResult,
			@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
			RedirectAttributes redirectAttributes) {
		if (bindingResult.hasErrors()) {
			return "reviews/edit";
		}

		//ログインユーザーの情報を取得
		User user = userDetailsImpl.getUser();

		reviewService.reviewUpdate(reviewEditForm, storeId, user);
		redirectAttributes.addFlashAttribute("successMessage", "レビューを更新しました。");
		return "redirect:/stores/" + storeId;
	}

	//レビュー削除フォーム用
	@PostMapping("reviewdelete/{reviewId}")
	public String delete(@PathVariable(name = "id") Integer storeId, @PathVariable(name = "reviewId") Integer reviewId,
			RedirectAttributes redirectAttributes) {
		
		reviewRepository.deleteById(reviewId);
		redirectAttributes.addFlashAttribute("successMessage", "レビューを削除しました。");

		return "redirect:/stores/" + storeId;
	}

}