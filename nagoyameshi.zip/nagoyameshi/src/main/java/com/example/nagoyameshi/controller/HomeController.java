//トップページ用コントローラ

package com.example.nagoyameshi.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.nagoyameshi.entity.Category;
import com.example.nagoyameshi.entity.Review;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.repository.CategoryRepository;
import com.example.nagoyameshi.repository.ReviewRepository;
import com.example.nagoyameshi.repository.StoreRepository;

@Controller
public class HomeController {
private final StoreRepository storeRepository;
private final CategoryRepository categoryRepository;
private final ReviewRepository reviewRepository;
    
    public HomeController(StoreRepository storeRepository, CategoryRepository categoryRepository, ReviewRepository reviewRepository) {
        this.storeRepository = storeRepository;
        this.categoryRepository = categoryRepository;
        this.reviewRepository = reviewRepository;
    }  
    
    @GetMapping("/")
    public String index(Model model) {
    	//新着店舗順5件取得
        List<Store> newStores = storeRepository.findTop5ByOrderByCreatedAtDesc();
        //高評価店舗順5件取得
        List<Review> highlyRatedStores = reviewRepository.findTop5ByOrderByStarRatingDesc();
        //全カテゴリ取得
        List<Category> allCategories = categoryRepository.findAll();
        
        model.addAttribute("newStores", newStores); 
        model.addAttribute("highlyRatedStores", highlyRatedStores);
        model.addAttribute("allCategories", allCategories);
        
        return "index";
    }   
}

