//パスワード変更フォーム

package com.example.nagoyameshi.form;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import lombok.Data;

@Data
public class ChangePasswordForm {
	
	@NotBlank(message = "氏名を入力してください。")
	private String userName;
	
    @NotBlank(message = "メールアドレスを入力してください。")
    @Email(message = "メールアドレスは正しい形式で入力してください。")
    private String email;
    
    @NotBlank(message = "新たに設定するパスワードを入力してください。")
    @Length(min = 8, message = "パスワードは8文字以上で入力してください。")
    private String changePassword;    
    
    @NotBlank(message = "新たに設定するパスワード（確認用）を入力してください。")
    private String changePasswordConfirmation; 

}
