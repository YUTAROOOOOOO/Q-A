//店舗登録フォーム

package com.example.nagoyameshi.form;

import jakarta.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class CategoryRegisterForm {
	
	@NotBlank(message = "カテゴリー名を入力して下さい。")
	private String categoryName;
	
}
