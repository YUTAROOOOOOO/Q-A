package com.example.nagoyameshi.service;

import java.sql.Timestamp;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.example.nagoyameshi.entity.Review;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ReviewEditForm;
import com.example.nagoyameshi.form.ReviewPostForm;
import com.example.nagoyameshi.repository.ReviewRepository;
import com.example.nagoyameshi.repository.StoreRepository;

@Service
public class ReviewService {
	private final ReviewRepository reviewRepository;
	private final StoreRepository storeRepository;

	public ReviewService(ReviewRepository reviewRepository, StoreRepository storeRepository) {
		this.reviewRepository = reviewRepository;
		this.storeRepository = storeRepository;
	}

	// レビューの作成
	@Transactional
	public void reviewCreate(ReviewPostForm reviewPostForm, Integer storeId, User user) {

		// 民宿を取得  
		Store store = storeRepository.getReferenceById(storeId);
		
		// 新しいReviewエンティティのインスタンスを作成  
		Review review = new Review();

		review.setStore(store); // 店舗を設定
		review.setUser(user); // ユーザーを設定  
		review.setStarRating(reviewPostForm.getStarRating()); // フォームからの評価を設定  
		review.setComment(reviewPostForm.getComment()); // フォームからのコメントを設定  
		review.setCreatedAt(new Timestamp(System.currentTimeMillis())); // 現在の日時を設定  

		reviewRepository.save(review); // レビューを保存  
	}

	// レビュー更新
	@Transactional
	public Review reviewUpdate(ReviewEditForm reviewEditForm, Integer storeId, User user) {
		// 民宿を取得  
		Store store = storeRepository.getReferenceById(storeId);
		//更新するレビューを取得
		Review review = reviewRepository.getReferenceById(reviewEditForm.getId());

		review.setStore(store); // 店舗を設定
		review.setUser(user); // ユーザーを設定  
		review.setStarRating(reviewEditForm.getStarRating()); // フォームからの評価を設定  
		review.setComment(reviewEditForm.getComment()); // フォームからのコメントを設定  
		review.setUpdatedAt(new Timestamp(System.currentTimeMillis())); // 現在の日時を設定  

		return reviewRepository.save(review);
	}
	
}
