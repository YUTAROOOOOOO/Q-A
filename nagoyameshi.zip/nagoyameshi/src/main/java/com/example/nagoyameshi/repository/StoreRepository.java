package com.example.nagoyameshi.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.nagoyameshi.entity.Store;
public interface StoreRepository extends JpaRepository<Store, Integer> {

	List<Store> findTop5ByOrderByCreatedAtDesc();

	Store getReferenceById(Store store);

	Page<Store> findByStoreNameLikeOrderByCreatedAtAsc(String storeNameKeyword, Pageable pageable);

	Page<Store> findByStoreNameLike(String storeName, Pageable pageable);

}

