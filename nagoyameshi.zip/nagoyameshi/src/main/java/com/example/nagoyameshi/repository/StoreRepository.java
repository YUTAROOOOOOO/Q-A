package com.example.nagoyameshi.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.nagoyameshi.entity.Category;
import com.example.nagoyameshi.entity.Store;
public interface StoreRepository extends JpaRepository<Store, Integer> {

	List<Store> findTop5ByOrderByCreatedAtDesc();

	Store getReferenceById(Store storeId);

	Page<Store> findByStoreNameLikeOrderByCreatedAtDesc(String storeNameKeyword, Pageable pageable);
	
	Page<Store> findByStoreNameLikeOrderByMinBudgetAsc(String storeNameKeyword, Pageable pageable);
	
	Page<Store> findByStoreNameLike(String storeName, Pageable pageable);
	
	Page<Store> findAllByOrderByCreatedAtAsc(Pageable pageable);
	
	Page<Store> findByCategoryOrderByCreatedAtAsc(String category, Pageable pageable);
	
	Page<Store> findAllByOrderByMaxBudgetAsc(Pageable pageable);
	
	Page<Store> findByMaxBudgetLessThanEqualOrderByCreatedAtDesc(Integer maxBudget, Pageable pageable);
	
	Page<Store> findByMaxBudgetLessThanEqualOrderByMinBudgetAsc(Integer maxBudget, Pageable pageable);
	
	Page<Store> findAllByOrderByMinBudgetAsc(Pageable pageable);
	
	Page<Store> findAllByOrderByCreatedAtDesc(Pageable pageable);
	
	Page<Store> findByCategoryOrderByMinBudgetAsc(Category categoryId, Pageable pageable);
	
	Page<Store> findByCategoryOrderByCreatedAtDesc(Category categoryId, Pageable pageable);

}

