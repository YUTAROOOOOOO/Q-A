package com.example.nagoyameshi.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.form.StoreEditForm;
import com.example.nagoyameshi.form.StoreRegisterForm;
import com.example.nagoyameshi.repository.StoreRepository;

@Service
public class StoreService {
	private final StoreRepository storeRepository;

	public StoreService(StoreRepository storerepository) {
		this.storeRepository = storerepository;
	}

	//1日を30分刻みの時間リストを作成
	public List<LocalTime> getTimeSlots() {
	    List<LocalTime> times = new ArrayList<>();

	    for (int i = 0; i <= 47; i++) { 
	    	LocalTime timeSlots = LocalTime.of(0, 0).plusMinutes(30 * i);
	    	times.add(timeSlots);
	    }

	    return times;
	}

	//店舗登録
	@Transactional
	public void create(StoreRegisterForm storeRegisterForm) {
		Store store = new Store();
		MultipartFile imageFile = storeRegisterForm.getImageFile();

		if (!imageFile.isEmpty()) {
			String imageName = imageFile.getOriginalFilename();
			String hashedImageName = generateNewFileName(imageName);
			Path filePath = Paths.get("src/main/resources/static/storage/" + hashedImageName);
			copyImageFile(imageFile, filePath);
			store.setImageName(hashedImageName);
		}

		store.setCategory(storeRegisterForm.getCategory());
		store.setStoreName(storeRegisterForm.getStoreName());
		store.setDescription(storeRegisterForm.getDescription());
		store.setCapacity(storeRegisterForm.getCapacity());
		store.setMinBudget(storeRegisterForm.getMinBudget());
		store.setMaxBudget(storeRegisterForm.getMaxBudget());
		store.setOpeningTime(storeRegisterForm.getOpeningTime());
		store.setClosingTime(storeRegisterForm.getClosingTime());
		store.setRegularHoliday(String.join(",", storeRegisterForm.getRegularHoliday()));
		store.setPostalCode(storeRegisterForm.getPostalCode());
		store.setAddress(storeRegisterForm.getAddress());
		store.setPhoneNumber(storeRegisterForm.getPhoneNumber());

		storeRepository.save(store);
	}

	//店舗情報編集
	@Transactional
	public void update(StoreEditForm storeEditForm) {
		Store store = storeRepository.getReferenceById(storeEditForm.getId());
		MultipartFile imageFile = storeEditForm.getImageFile();

		if (!imageFile.isEmpty()) {
			String imageName = imageFile.getOriginalFilename();
			String hashedImageName = generateNewFileName(imageName);
			Path filePath = Paths.get("src/main/resources/static/storage/" + hashedImageName);
			copyImageFile(imageFile, filePath);
			store.setImageName(hashedImageName);
		}

		store.setCategory(storeEditForm.getCategory());
		store.setStoreName(storeEditForm.getStoreName());
		store.setDescription(storeEditForm.getDescription());
		store.setCapacity(storeEditForm.getCapacity());
		store.setMinBudget(storeEditForm.getMinBudget());
		store.setMaxBudget(storeEditForm.getMaxBudget());
		store.setOpeningTime(storeEditForm.getOpeningTime());
		store.setClosingTime(storeEditForm.getClosingTime());
		store.setRegularHoliday(String.join(",", storeEditForm.getRegularHoliday()));
		store.setPostalCode(storeEditForm.getPostalCode());
		store.setAddress(storeEditForm.getAddress());
		store.setPhoneNumber(storeEditForm.getPhoneNumber());

		storeRepository.save(store);
	}

	//UUIDを使って生成したファイル名を返す
	public String generateNewFileName(String fileName) {
		String[] fileNames = fileName.split("\\.");
		for (int i = 0; i < fileNames.length - 1; i++) {
			fileNames[i] = UUID.randomUUID().toString();
		}
		String hashedFileName = String.join(".", fileNames);
		return hashedFileName;
	}

	//画像ファイルを指定したファイルにコピーする
	public void copyImageFile(MultipartFile imageFile, Path filePath) {
		try {
			Files.copy(imageFile.getInputStream(), filePath);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
