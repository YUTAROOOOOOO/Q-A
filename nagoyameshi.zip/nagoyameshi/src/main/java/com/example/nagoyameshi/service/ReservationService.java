package com.example.nagoyameshi.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Map;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.example.nagoyameshi.entity.Reservation;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.repository.ReservationRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.repository.UserRepository;

@Service
public class ReservationService {

	private final ReservationRepository reservationRepository;
	private final StoreRepository storeRepository;
	private final UserRepository userRepository;

	public ReservationService(ReservationRepository reservationRepository, StoreRepository storeRepository,
			UserRepository userRepository) {
		this.reservationRepository = reservationRepository;
		this.storeRepository = storeRepository;
		this.userRepository = userRepository;
	}
	
	//予約登録　カレンダーから選択方式
	@Transactional
	public void create(Map<String, String> paymentIntentObject) {
		Reservation reservation = new Reservation();
//どうやってuserとstoreを取得する？？？？？？
		Integer storeId = Integer.valueOf(paymentIntentObject.get("storeId"));
		Integer userId = Integer.valueOf(paymentIntentObject.get("userId"));

		Store store = storeRepository.getReferenceById(storeId);
		User user = userRepository.getReferenceById(userId);
		LocalDate reservationDate = LocalDate.parse(paymentIntentObject.get("reservationDate"));
		LocalTime reservationTime = LocalTime.parse(paymentIntentObject.get("reservationTime"));
		Integer numberOfPeople = Integer.valueOf(paymentIntentObject.get("numberOfPeople"));

		reservation.setStore(store);
		reservation.setUser(user);
		reservation.setReservationDate(reservationDate);
		reservation.setReservationTime(reservationTime);
		reservation.setNumberOfPeople(numberOfPeople);

		reservationRepository.save(reservation);
	}

	//予約人数が定員以下かどうかをチェックする
	public boolean isWithinCapacity(Integer numberOfPeople, Integer capacity) {
		return numberOfPeople <= capacity;
	}
	
//	//30分刻みの時間リストを作成
//	public List<LocalTime> generateReservationTimes(LocalTime openingTime, LocalTime closingTime) {
//	    List<LocalTime> times = new ArrayList<>();
//	    LocalTime time = openingTime;
//
//	    while (!time.isAfter(closingTime.minusMinutes(30))) {
//	        times.add(time);
//	        time = time.plusMinutes(30);
//	    }
//
//	    return times;
//	}
}
