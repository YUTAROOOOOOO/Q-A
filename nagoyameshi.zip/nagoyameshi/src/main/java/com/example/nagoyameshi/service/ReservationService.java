package com.example.nagoyameshi.service;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.example.nagoyameshi.entity.Reservation;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ReservationRegisterForm;
import com.example.nagoyameshi.repository.ReservationRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.repository.UserRepository;

@Service
public class ReservationService {

	private final ReservationRepository reservationRepository;
	private final StoreRepository storeRepository;
	private final UserRepository userRepository;

	public ReservationService(ReservationRepository reservationRepository, StoreRepository storeRepository,
			UserRepository userRepository) {
		this.reservationRepository = reservationRepository;
		this.storeRepository = storeRepository;
		this.userRepository = userRepository;
	}

	//予約済みの時間を取得
	public List<LocalTime> getReservedTimes(Integer storeId, LocalDate reservationDate) {
	    List<Reservation> reservations = reservationRepository.findByStoreIdAndReservationDate(storeId, reservationDate);
	    // reservationTimeだけ抽出
	    return reservations.stream()
	                       .map(Reservation::getReservationTime)
	                       .collect(Collectors.toList());
	}
	
	//営業時間内で30分刻みの時間リストを作成
	public List<String> getReservationTimeSlots(LocalTime openingTime, LocalTime closingTime, List<LocalTime> reservedTimes) {
		List<String> slots = new ArrayList<>();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
		LocalTime time = openingTime;
		boolean crossesMidnight = closingTime.isBefore(openingTime) || closingTime.equals(LocalTime.MIDNIGHT);

		// 通常の日内の場合
		if (!crossesMidnight) {
			while (!time.isAfter(closingTime)) {
				if (!reservedTimes.contains(time)) {
					slots.add(time.format(formatter));
				}
				time = time.plusMinutes(30);
			}
		} else {
			// 日を跨ぐ場合（例：19:00〜翌3:00）
			while (!time.equals(LocalTime.MIDNIGHT)) {
				if (!reservedTimes.contains(time)) {
					slots.add(time.format(formatter));
				}
				time = time.plusMinutes(30);
			}

			// 00:00〜closingTimeまで追加
			time = LocalTime.MIDNIGHT;
			while (!time.isAfter(closingTime)) {
				if (!reservedTimes.contains(time)) {
					if (time.equals(LocalTime.MIDNIGHT)) {
						slots.add("24:00");
					} else {
						slots.add(time.format(formatter));
					}
				}
				time = time.plusMinutes(30);
			}
		}
		return slots;
	}

	@Transactional
	public void create(ReservationRegisterForm reservationRegisterForm, Integer storeId, Integer userId) {

		// 店舗を取得  
		Store store = storeRepository.getReferenceById(storeId);
		// ユーザーを取得
		User user = userRepository.getReferenceById(userId);
		 
		Reservation reservation = new Reservation();

		reservation.setStore(store);
		reservation.setUser(user); 
		reservation.setReservationDate(reservationRegisterForm.getReservationDate());
		reservation.setReservationTime(reservationRegisterForm.getReservationTime());
		reservation.setNumberOfPeople(reservationRegisterForm.getNumberOfPeople());
		reservation.setCreatedAt(new Timestamp(System.currentTimeMillis())); // 現在の日時を設定  

		reservationRepository.save(reservation);
	}


	//予約人数が定員以下かどうかをチェックする
	public boolean isWithinCapacity(Integer numberOfPeople, Integer capacity) {
		return numberOfPeople <= capacity;
	}

	//予約日が定休日以外かどうかをチェックする

}
