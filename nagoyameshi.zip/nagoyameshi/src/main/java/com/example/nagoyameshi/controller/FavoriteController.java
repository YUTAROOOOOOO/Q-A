package com.example.nagoyameshi.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.nagoyameshi.entity.Favorite;
import com.example.nagoyameshi.repository.FavoriteRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.repository.UserRepository;
import com.example.nagoyameshi.security.UserDetailsImpl;
import com.example.nagoyameshi.service.FavoriteService;

@Controller
public class FavoriteController {
	private final FavoriteService favoriteService;
	private final FavoriteRepository favoriteRepository;

	public FavoriteController(FavoriteService favoriteService, UserRepository userRepository,
			StoreRepository storeRepository, FavoriteRepository favoriteRepository) {
		this.favoriteService = favoriteService;
		this.favoriteRepository = favoriteRepository;
	}

	//お気に入り一覧ページ
	@GetMapping("/favorites")
	public String index(
			@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
			@PageableDefault(page = 0, size = 10, sort = "id", direction = Direction.ASC) Pageable pageable,
			Model model) {
		Integer userId = userDetailsImpl.getUser().getId();
//	    Page<Favorite> favoritePage = favoriteService.getFavoritesByUserId(userId, pageable);
	    Page<Favorite> favoritePage = favoriteRepository.findByUserId(userId, pageable);

		model.addAttribute("favoritePage", favoritePage);
		
		return "favorites/index";
	}
	
	// 登録
	@PostMapping("/favorite/{storeId}/create")
	public String addFavorite(@PathVariable(name = "storeId") Integer storeId,
			@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
			RedirectAttributes redirectAttributes) {
		Integer userId = userDetailsImpl.getUser().getId();
		favoriteService.createFavorite(userId, storeId);
		
		redirectAttributes.addFlashAttribute("successMessage", "お気に入りに追加しました。");
		
		return "redirect:/stores/" + storeId;
	}

	// 解除
	@PostMapping("/favorite/{storeId}/remove")
	public String removeFavorite(@PathVariable(name = "storeId") Integer storeId,
			@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
			RedirectAttributes redirectAttributes) {
		Integer userId = userDetailsImpl.getUser().getId();
		favoriteService.removeFavorite(userId, storeId);
		
		redirectAttributes.addFlashAttribute("successMessage", "お気に入りを解除しました。");
		
		return "redirect:/stores/" + storeId;
	}
}
