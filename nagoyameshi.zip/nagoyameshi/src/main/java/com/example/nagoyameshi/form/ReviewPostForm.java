//レビュー投稿

package com.example.nagoyameshi.form;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import lombok.Data;

@Data
public class ReviewPostForm {
	@NotNull(message = "星評価を選択してください。")
	@Min(value = 1, message = "評価は星1以上にしてください。")
	@Max(value = 5, message = "評価は星5以下にしてください。")
	private Integer starRating;
	
	@NotBlank(message = "レビューコメントを入力してください。")
	private String comment;
}
