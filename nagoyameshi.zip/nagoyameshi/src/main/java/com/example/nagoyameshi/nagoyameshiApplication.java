package com.example.nagoyameshi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class nagoyameshiApplication {

	public static void main(String[] args) {
		SpringApplication.run(nagoyameshiApplication.class, args);
	}

}
