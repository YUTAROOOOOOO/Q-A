package com.example.nagoyameshi.repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.nagoyameshi.entity.Reservation;
import com.example.nagoyameshi.entity.User;

public interface ReservationRepository extends JpaRepository<Reservation, Integer> {

	Page<Reservation> findByUserOrderByCreatedAtDesc(User user, Pageable pageable);

	List<Reservation> findByStoreIdAndReservationDate(Integer storeId, LocalDate reservationDate);
	
	@Query("SELECT COALESCE(SUM(r.numberOfPeople), 0) FROM Reservation r WHERE r.store.id = :storeId AND r.reservationDate = :reservationDate AND r.reservationTime = :reservationTime")
	Integer countReservedNumberOfPeopleByStoreAndTime(
	    @Param("storeId") Integer storeId,
	    @Param("reservationDate") LocalDate reservationDate,
	    @Param("reservationTime") LocalTime reservationTime
	);

	
	// 同じ店舗、日時での予約が存在するかを確認するメソッド
	boolean existsByStoreIdAndReservationDateAndReservationTime(Integer storeId, LocalDate reservationDate,
			LocalTime reservationTime);

}
