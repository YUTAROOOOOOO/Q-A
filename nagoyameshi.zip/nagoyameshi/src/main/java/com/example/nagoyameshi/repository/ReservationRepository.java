package com.example.nagoyameshi.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.nagoyameshi.entity.Reservation;
import com.example.nagoyameshi.entity.User;

public interface ReservationRepository extends JpaRepository<Reservation, Integer> {

	Page<Reservation> findByUserOrderByCreatedAtDesc(User user, Pageable pageable);

	List<Reservation> findByStoreIdAndReservationDate(Integer storeId, LocalDate reservationDate);
	
//	@Query("SELECT r.reservationTime FROM Reservation r WHERE r.store.id = :storeId AND r.reservationDate = :reservationDate")
//	List<LocalTime> getReservedTimes(@Param("storeId") Integer storeId, @Param("reservationDate") LocalDate reservationDate);


}
