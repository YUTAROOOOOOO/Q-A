//店舗関係コントローラ

package com.example.nagoyameshi.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.nagoyameshi.entity.Category;
import com.example.nagoyameshi.entity.Review;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ReservationInputForm;
import com.example.nagoyameshi.repository.CategoryRepository;
import com.example.nagoyameshi.repository.ReviewRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.security.UserDetailsImpl;
import com.example.nagoyameshi.service.FavoriteService;
import com.example.nagoyameshi.service.ReservationService;

@Controller
@RequestMapping("/stores")
public class StoreController {
	private final StoreRepository storeRepository;
	private final ReviewRepository reviewRepository;//定数の宣言
	private final CategoryRepository categoryRepository;
	private final FavoriteService favoriteService;

	public StoreController(StoreRepository storeRepository, ReviewRepository reviewRepository,
			CategoryRepository categoryRepository, ReservationService reservationService,
			FavoriteService favoriteService) {
		this.storeRepository = storeRepository;
		this.reviewRepository = reviewRepository;//定数の代入
		this.categoryRepository = categoryRepository;
		this.favoriteService = favoriteService;

	}

	//店舗一覧ページ取得
	@GetMapping
	public String index(@RequestParam(name = "keyword", required = false) String keyword,
			@RequestParam(name = "categoryId", required = false) Integer categoryId,
			@RequestParam(name = "maxBudget", required = false) Integer maxBudget,
			@RequestParam(name = "order", required = false) String order,
			@RequestParam(name = "page", defaultValue = "0") Integer page,
			Model model) {

		// 並び順の処理
		Sort sort = Sort.by(Sort.Direction.DESC, "createdAt");
		if ("minBudgetAsc".equals(order)) {
			sort = Sort.by(Sort.Direction.ASC, "minBudget");
		} else if ("maxBudgetDesc".equals(order)) {
			sort = Sort.by(Sort.Direction.DESC, "maxBudget");
		}
		
		//ページネーション条件
		Pageable pageable = PageRequest.of(page, 10, sort);

		 // 検索条件を組み立てる
	    Specification<Store> spec = Specification.where(null);

	    //店舗名で検索した場合
	    if (keyword != null && !keyword.isEmpty()) {
	        spec = spec.and((root, query, cb) ->
	                cb.like(root.get("storeName"), "%" + keyword + "%"));
	    }
	    //カテゴリー名で検索した場合
	    if (categoryId != null) {
	        Category category = categoryRepository.findById(categoryId).orElse(null);
	        if (category != null) {
	            spec = spec.and((root, query, cb) ->
	                    cb.equal(root.get("category"), category));
	        }
	    }
	    //予算で検索した場合
	    if (maxBudget != null) {
	        spec = spec.and((root, query, cb) ->
	                cb.lessThanOrEqualTo(root.get("maxBudget"), maxBudget));
	    }

	    // 検索実行し、storeエンティティを取得
	    Page<Store> storePage = storeRepository.findAll(spec, pageable);
	    //全カテゴリー取得
		List<Category> allCategories = categoryRepository.findAll();

		model.addAttribute("storePage", storePage);
		model.addAttribute("allCategories", allCategories);
		model.addAttribute("keyword", keyword);
		model.addAttribute("categoryId", categoryId);
		model.addAttribute("maxBudget", maxBudget);
		model.addAttribute("order", order);

		return "stores/index";
	}

	//店舗詳細ページ取得
	@GetMapping("/{storeId}")
	public String show(@PathVariable(name = "storeId") Integer storeId, Model model,
			@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
			@ModelAttribute ReservationInputForm reservationInputForm) {

		//storeエンティティのプロキシを取得
		Store store = storeRepository.getReferenceById(storeId);
		//店舗のレビューを投稿順に6件取得
		List<Review> reviews = reviewRepository.findTop6BystoreOrderByUpdatedAtDesc(store);
		//店舗のレビューを投稿順に全て取得
		List<Review> allReviews = reviewRepository.findBystoreOrderByUpdatedAtDesc(store);

		//ログインユーザーの情報を取得（ログインしていない場合は null）
		User user = (userDetailsImpl != null) ? userDetailsImpl.getUser() : null;
		boolean isFavorited = false;
		
		//ログインしている場合
		if (user != null) {
			Integer userId = userDetailsImpl.getUser().getId();
			//ユーザーがお気に入り済みかを判定
			isFavorited = favoriteService.isFavorited(userId, storeId);
		}

		model.addAttribute("store", store);
		model.addAttribute("reservationInputForm", new ReservationInputForm());
		model.addAttribute("reviews", reviews);
		model.addAttribute("allReviews", allReviews);
		model.addAttribute("user", user);
		model.addAttribute("isFavorited", isFavorited);

		return "stores/show";
	}

	//カテゴリー別の店舗取得
	@GetMapping("/category/{categoryId}")
	public String sheachCategory(@PathVariable(name = "categoryId") Integer categoryId,
			@RequestParam(name = "keyword", required = false) String keyword,
			@RequestParam(name = "maxBudget", required = false) Integer maxBudget,
			@RequestParam(name = "order", required = false) String order,
			@RequestParam(name = "page", defaultValue = "0") Integer page,
			Model model) {

		// 並び順の処理
		Sort sort = Sort.by(Sort.Direction.DESC, "createdAt");
		if ("minBudgetAsc".equals(order)) {
			sort = Sort.by(Sort.Direction.ASC, "minBudget");
		} else if ("maxBudgetDesc".equals(order)) {
			sort = Sort.by(Sort.Direction.DESC, "maxBudget");
		}
		
		//ページネーション条件
		Pageable pageable = PageRequest.of(page, 10, sort);

		 // 検索条件を組み立てる
	    Specification<Store> spec = Specification.where(null);

	  //店舗名で検索した場合
	    if (keyword != null && !keyword.isEmpty()) {
	        spec = spec.and((root, query, cb) ->
	                cb.like(root.get("storeName"), "%" + keyword + "%"));
	    }
	  //カテゴリー名で検索した場合
	    if (categoryId != null) {
	        Category category = categoryRepository.findById(categoryId).orElse(null);
	        if (category != null) {
	            spec = spec.and((root, query, cb) ->
	                    cb.equal(root.get("category"), category));
	        }
	    }
	  //予算で検索した場合
	    if (maxBudget != null) {
	        spec = spec.and((root, query, cb) ->
	                cb.lessThanOrEqualTo(root.get("maxBudget"), maxBudget));
	    }

	    // 検索実行し、storeエンティティを取得
	    Page<Store> storePage = storeRepository.findAll(spec, pageable);
	    //全カテゴリー取得
		List<Category> allCategories = categoryRepository.findAll();

		model.addAttribute("storePage", storePage);
		model.addAttribute("allCategories", allCategories);
		model.addAttribute("keyword", keyword);
		model.addAttribute("categoryId", categoryId);
		model.addAttribute("maxBudget", maxBudget);
		model.addAttribute("order", order);
		
		return "stores/index";
	}

}
