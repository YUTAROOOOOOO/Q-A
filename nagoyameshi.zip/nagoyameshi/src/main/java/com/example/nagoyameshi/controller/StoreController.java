//店舗関係コントローラ

package com.example.nagoyameshi.controller;

import java.util.List;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.nagoyameshi.entity.Review;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ReservationInputForm;
import com.example.nagoyameshi.repository.ReviewRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.repository.UserRepository;
import com.example.nagoyameshi.security.UserDetailsImpl;

@Controller
@RequestMapping("/stores")
public class StoreController {
	private final StoreRepository storeRepository;
	private final ReviewRepository reviewRepository;//定数の宣言

	public StoreController(StoreRepository storeRepository, ReviewRepository reviewRepository,
			UserRepository userRepository) {
		this.storeRepository = storeRepository;
		this.reviewRepository = reviewRepository;//定数の代入
	}

//	@GetMapping
//	public String index(@RequestParam(name = "keyword", required = false) String keyword,
//			@RequestParam(name = "category", required = false) String category,
//			@RequestParam(name = "maxBudget", required = false) Integer maxBudget,
//			@RequestParam(name = "order", required = false) String order,
//			@PageableDefault(page = 0, size = 10, sort = "id", direction = Direction.ASC) Pageable pageable,
//			Model model) {
//
//		Page<Store> storePage;
//
//		if (keyword != null && !keyword.isEmpty()) {
//			if (order != null && order.equals("CreatedAtAsc")) {
//				storePage = storeRepository.findByStoreNameLikeOrderByCreatedAtAsc("%" + keyword + "%", pageable);
//			} else {
//				storePage = storeRepository.findByNameLikeOrAddressLikeOrderByCreatedAtDesc("%" + keyword + "%",
//						"%" + keyword + "%", pageable);
//			}
//		} else if (area != null && !area.isEmpty()) {
//			if (order != null && order.equals("priceAsc")) {
//				storePage = storeRepository.findByAddressLikeOrderByPriceAsc("%" + area + "%", pageable);
//			} else {
//				storePage = storeRepository.findByAddressLikeOrderByCreatedAtDesc("%" + area + "%", pageable);
//			}
//		} else if (price != null) {
//			if (order != null && order.equals("priceAsc")) {
//				storePage = storeRepository.findByPriceLessThanEqualOrderByPriceAsc(price, pageable);
//			} else {
//				storePage = storeRepository.findByPriceLessThanEqualOrderByCreatedAtDesc(price, pageable);
//			}
//		} else {
//			if (order != null && order.equals("priceAsc")) {
//				storePage = storeRepository.findAllByOrderByPriceAsc(pageable);
//			} else {
//				storePage = storeRepository.findAllByOrderByCreatedAtDesc(pageable);
//			}
//		}
//
//		model.addAttribute("storePage", storePage);
//		model.addAttribute("keyword", keyword);
//		model.addAttribute("area", area);
//		model.addAttribute("price", price);
//		model.addAttribute("order", order);
//
//		return "stores/index";
//	}
	
	//店舗詳細ページ取得
	@GetMapping("/{id}")
    public String show(@PathVariable(name = "id") Integer storeId, Model model, @AuthenticationPrincipal UserDetailsImpl userDetailsImpl) {
        Store store = storeRepository.getReferenceById(storeId);
        List<Review> reviews = reviewRepository.findTop6BystoreOrderByUpdatedAtDesc(store);
        List<Review> allReviews = reviewRepository.findBystoreOrderByUpdatedAtDesc(store);
		//ログインユーザーの情報を取得（ログインしていない場合は null）
        User user = (userDetailsImpl != null) ? userDetailsImpl.getUser() : null;
        
        model.addAttribute("store", store);
        model.addAttribute("reservationInputForm", new ReservationInputForm());
        model.addAttribute("reviews", reviews);
        model.addAttribute("allReviews", allReviews);
        model.addAttribute("user", user);

        return "stores/show";
    }    

}
