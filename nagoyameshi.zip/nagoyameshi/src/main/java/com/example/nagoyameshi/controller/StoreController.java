//店舗関係コントローラ

package com.example.nagoyameshi.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.nagoyameshi.entity.Category;
import com.example.nagoyameshi.entity.Review;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ReservationInputForm;
import com.example.nagoyameshi.repository.CategoryRepository;
import com.example.nagoyameshi.repository.ReviewRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.security.UserDetailsImpl;
import com.example.nagoyameshi.service.FavoriteService;
import com.example.nagoyameshi.service.ReservationService;

@Controller
@RequestMapping("/stores")
public class StoreController {
	private final StoreRepository storeRepository;
	private final ReviewRepository reviewRepository;//定数の宣言
	private final CategoryRepository categoryRepository;
	private final ReservationService reservationService;
	private final FavoriteService favoriteService;

	public StoreController(StoreRepository storeRepository, ReviewRepository reviewRepository,
			CategoryRepository categoryRepository, ReservationService reservationService,
			FavoriteService favoriteService) {
		this.storeRepository = storeRepository;
		this.reviewRepository = reviewRepository;//定数の代入
		this.categoryRepository = categoryRepository;
		this.reservationService = reservationService;
		this.favoriteService = favoriteService;
		
	}

	//店舗一覧ページ取得
	@GetMapping
	public String index(@RequestParam(name = "keyword", required = false) String keyword,
			@RequestParam(name = "category", required = false) Category categoryId,
			@RequestParam(name = "maxBudget", required = false) Integer maxBudget,
			@RequestParam(name = "order", required = false) String order,
			@PageableDefault(page = 0, size = 10, sort = "id", direction = Direction.ASC) Pageable pageable,
			Model model) {

		Page<Store> storePage;
		List<Category> allCategories = categoryRepository.findAll();

		if (keyword != null && !keyword.isEmpty()) {
			if (order != null && order.equals("minBudgetAsc")) {
				storePage = storeRepository.findByStoreNameLikeOrderByMinBudgetAsc("%" + keyword + "%", pageable);
			} else {
				storePage = storeRepository.findByStoreNameLikeOrderByCreatedAtDesc("%" + keyword + "%", pageable);
			}
		} else if (categoryId != null) {
			if (order != null && order.equals("minBudgetAsc")) {
				storePage = storeRepository.findByCategoryOrderByMinBudgetAsc(categoryId, pageable);
			} else {
				storePage = storeRepository.findByCategoryOrderByCreatedAtDesc(categoryId, pageable);
			}
		} else if (maxBudget != null) {
			if (order != null && order.equals("minBudgetAsc")) {
				storePage = storeRepository.findByMaxBudgetLessThanEqualOrderByMinBudgetAsc(maxBudget, pageable);
			} else {
				storePage = storeRepository.findByMaxBudgetLessThanEqualOrderByCreatedAtDesc(maxBudget, pageable);
			}
		} else {
			if (order != null && order.equals("minBudgetAsc")) {
				storePage = storeRepository.findAllByOrderByMinBudgetAsc(pageable);
			} else {
				storePage = storeRepository.findAllByOrderByCreatedAtDesc(pageable);
			}
		}

		model.addAttribute("storePage", storePage);
		model.addAttribute("allCategories", allCategories);
		model.addAttribute("keyword", keyword);
		model.addAttribute("categoryId", categoryId);
		model.addAttribute("maxBudget", maxBudget);
		model.addAttribute("order", order);

		return "stores/index";
	}

	//店舗詳細ページ取得
	@GetMapping("/{id}")
	public String show(@PathVariable(name = "id") Integer storeId, Model model,
			@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,
			@ModelAttribute ReservationInputForm reservationInputForm) {
		Store store = storeRepository.getReferenceById(storeId);
		
		List<Review> reviews = reviewRepository.findTop6BystoreOrderByUpdatedAtDesc(store);
		List<Review> allReviews = reviewRepository.findBystoreOrderByUpdatedAtDesc(store);
		//予約済み時間を取得
		 LocalDate reservationDate = reservationInputForm.getReservationDate();
		    List<LocalTime> reservedTimes = new ArrayList<>();
		    if (reservationDate != null) {
		        reservedTimes = reservationService.getReservedTimes(storeId, reservationDate);
		    }
	     //営業時間に基づくスロットを生成
	    List<String> timeSlots = reservationService.getReservationTimeSlots(
	        store.getOpeningTime(), store.getClosingTime(), reservedTimes);
	    
	  //ログインユーザーの情報を取得（ログインしていない場合は null）
	  	User user = (userDetailsImpl != null) ? userDetailsImpl.getUser() : null;
	  	boolean isFavorited = false;
		
		if (user != null) {
		Integer userId = userDetailsImpl.getUser().getId();
		//ユーザーがお気に入り済みかを判定
		isFavorited = favoriteService.isFavorited(userId, storeId);
		}
		
		model.addAttribute("store", store);
		model.addAttribute("reservationInputForm", new ReservationInputForm());
		model.addAttribute("reviews", reviews);
		model.addAttribute("allReviews", allReviews);
		model.addAttribute("user", user);
		model.addAttribute("timeSlots", timeSlots);
		model.addAttribute("isFavorited", isFavorited);

		return "stores/show";
	}
	
	//カテゴリー別の店舗取得
	@GetMapping("/category/{id}")
	public String sheachCategory(@PathVariable(name = "id") Category categoryId, 
			@PageableDefault(page = 0, size = 10, sort = "id", direction = Direction.ASC) Pageable pageable, 
			Model model) {
		Page<Store> storePage;
		if (categoryId != null) {
					storePage = storeRepository.findByCategoryOrderByMinBudgetAsc(categoryId, pageable);
				} else {
					storePage = storeRepository.findByCategoryOrderByCreatedAtDesc(categoryId, pageable);
				}
		
		model.addAttribute("storePage", storePage);
		model.addAttribute("categoryId", categoryId);
		
		return "stores/index";
	}
	
//	//お気に入り追加
//	@PostMapping("/{storeId}/create")
//	public void favoriteCreate(@PathVariable(name = "storeId") Store storeId, Model model) {
//		Favorite favorite = new Favorite();
//		
//		model.addAttribute("favorite", favorite);
//	}
	
	

}
